tsm: A Typescript Vector and Matrix Math Library
=================================================

tsm is a a collection of vector, matrix and quaternion classes written in Typescript by Matthias Ferch.

The library's design is influenced by both [gl-matrix](https://github.com/toji/gl-matrix) and [glm](https://github.com/g-truc/glm). 

This is a modified version to fit the needs of UTCS. Find the original source on [github](https://github.com/matthiasferch/tsm).