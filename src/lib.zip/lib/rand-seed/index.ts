import Rand, { PRNG } from './Rand';

export default Rand;
export { PRNG };
